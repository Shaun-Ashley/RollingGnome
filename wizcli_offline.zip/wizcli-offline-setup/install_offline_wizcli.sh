#!/bin/bash
# Offline Install Script for Wiz CLI on Primary Device (M1 Mac, macOS Sequoia)
set -euo pipefail
cd "$(dirname "$0")"
echo "[*] Starting Wiz CLI offline installation..."

# Validate required wheels in the packages directory
for pattern in "wiz_env-*.whl" "ujson-*.whl" "setuptools-*.whl" "wheel-*.whl"; do
    if ! ls packages/"$pattern" >/dev/null 2>&1; then
        echo "[✗] ERROR: Missing required wheel: $pattern"
        exit 1
    fi
done

echo "[*] Creating Python virtual environment..."
python3 -m venv env
source env/bin/activate

echo "[*] Installing offline tools (setuptools and wheel)..."
pip install --no-index --find-links=packages setuptools wheel

echo "[*] Installing wiz-env from offline packages..."
pip install --no-index --find-links=packages --no-build-isolation wiz-env

echo ""
echo "[✓] Wiz CLI installed successfully."
echo -n "[✓] Wiz CLI version: "
wiz --version
echo ""
echo "To reactivate this environment later, run: source env/bin/activate"

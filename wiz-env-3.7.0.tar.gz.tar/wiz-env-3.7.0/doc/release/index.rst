.. _release:

***************************
Release and migration notes
***************************

Find out what has changed between versions and see important migration notes to
be aware of when switching to a new version.

.. toctree::
    :maxdepth: 1

    release_notes
    migration_notes

.. _api_reference:

*************
API Reference
*************

wiz
===

.. automodule:: wiz

.. toctree::
    :maxdepth: 1
    :glob:

    *

**********
wiz.config
**********

.. automodule:: wiz.config

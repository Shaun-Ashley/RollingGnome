**********
wiz.symbol
**********

.. automodule:: wiz.symbol

***********
wiz.history
***********

.. automodule:: wiz.history

****************
wiz.command_line
****************

.. automodule:: wiz.command_line

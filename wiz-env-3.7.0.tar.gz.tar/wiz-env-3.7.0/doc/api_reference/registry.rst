************
wiz.registry
************

.. automodule:: wiz.registry

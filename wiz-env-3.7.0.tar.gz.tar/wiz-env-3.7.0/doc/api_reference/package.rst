***********
wiz.package
***********

.. automodule:: wiz.package

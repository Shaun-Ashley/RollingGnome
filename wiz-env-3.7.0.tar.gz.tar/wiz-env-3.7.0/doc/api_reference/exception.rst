*************
wiz.exception
*************

.. automodule:: wiz.exception

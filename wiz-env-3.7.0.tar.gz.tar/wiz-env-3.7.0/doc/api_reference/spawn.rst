*********
wiz.spawn
*********

.. automodule:: wiz.spawn

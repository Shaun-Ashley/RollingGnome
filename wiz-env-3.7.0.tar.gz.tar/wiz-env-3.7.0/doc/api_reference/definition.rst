**************
wiz.definition
**************

.. automodule:: wiz.definition

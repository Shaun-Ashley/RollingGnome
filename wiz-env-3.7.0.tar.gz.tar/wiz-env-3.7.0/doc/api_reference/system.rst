**********
wiz.system
**********

.. automodule:: wiz.system

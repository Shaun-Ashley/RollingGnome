.. _main:

###
Wiz
###

.. toctree::
    :maxdepth: 1

    introduction
    installing
    getting_started
    configuration
    plugins
    registry
    definition
    guidelines
    command_line
    environment_variables
    api_reference/index
    release/index
    glossary

******************
Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _command_line:

************
Command line
************

.. click:: wiz.command_line:main
   :prog: wiz
   :show-nested:
